const MAX=3500000;
module.exports=async function(req,res){
 res.setHeader('Cache-Control','no-store');
 const fail=(code,error)=>res.status(code).json({ok:false,error});
 if(req.method!=='POST'){res.setHeader('Allow','POST');return fail(405,'Nur POST erlaubt.');}
 const allowed=new Set(['https://mopedauto24-ankauf.de','https://www.mopedauto24-ankauf.de']);if(process.env.VERCEL_URL)allowed.add('https://'+process.env.VERCEL_URL);if(process.env.ALLOWED_ORIGIN)allowed.add(process.env.ALLOWED_ORIGIN);
 if(!allowed.has(req.headers.origin))return fail(403,'Anfrage nicht erlaubt.');
 if(!String(req.headers['content-type']||'').startsWith('application/json'))return fail(415,'Ungültiges Format.');
 let d;try{d=typeof req.body==='string'?JSON.parse(req.body):req.body;if(!d||typeof d!=='object'||Array.isArray(d)||JSON.stringify(d).length>MAX)return fail(413,'Anfrage zu groß.');}catch{return fail(400,'Ungültige Anfrage.');}
 if(d.website)return fail(400,'Anfrage nicht erlaubt.');
 const fields={vehicle:['Fahrzeug',120,true],year:['Baujahr',4,false],km:['Kilometerstand',6,false],country:['Land',20,true],location:['Standort',120,true],drive:['Fahrbereitschaft',50,true],condition:['Zustand',2500,true],price:['Preisvorstellung',7,false],name:['Name',100,true],email:['E-Mail',254,true],phone:['Telefon',50,false]};
 const values={};for(const [key,[label,max,required]] of Object.entries(fields)){const value=d[key]??'';if(typeof value!=='string'||value.length>max||(required&&!value.trim()))return fail(400,'Bitte '+label+' prüfen.');values[key]=value.trim();}
 if(!/^[^\s@\r\n]+@[^\s@\r\n]+\.[^\s@\r\n]+$/.test(values.email)||!['Deutschland','Österreich'].includes(values.country)||d.privacy!=='on'||!['Fahrbereit','Motor läuft, nicht fahrbereit','Startet nicht','Unbekannt'].includes(values.drive))return fail(400,'Bitte Pflichtangaben prüfen.');
 for(const [key,min,max] of [['year',1950,2100],['km',0,999999],['price',0,1000000]])if(values[key]&&(!/^\d+$/.test(values[key])||Number(values[key])<min||Number(values[key])>max))return fail(400,'Ungültige Zahlenangabe.');
 if(!Array.isArray(d.photos)||d.photos.length>5)return fail(400,'Maximal fünf Fotos.');
 let bytes=0;const attachments=[];for(const [i,p] of d.photos.entries()){if(typeof p!=='string'||!/^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(p))return fail(400,'Ungültiges Bildformat.');const b=Buffer.from(p,'base64');bytes+=b.length;if(b.length<4||b[0]!==255||b[1]!==216||b[2]!==255||b[b.length-2]!==255||b[b.length-1]!==217||bytes>2500000)return fail(400,'Ungültige oder zu große Fotos.');attachments.push({filename:`fahrzeug-${i+1}.jpg`,content:p});}
 if(!process.env.RESEND_API_KEY||!process.env.MAIL_FROM)return fail(503,'Der Onlineversand ist noch nicht eingerichtet. Bitte kontaktieren Sie uns per E-Mail.');
 // Optional production anti-bot protection at Vercel Firewall; never expose provider credentials in the browser.
 try{const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+process.env.RESEND_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.MAIL_FROM,to:['info@hilprecht-motoren.de'],reply_to:values.email,subject:'Neue Mopedauto24 Ankaufanfrage',text:Object.entries(fields).map(([key,[label]])=>label+': '+(values[key]||'–')).join('\n')+'\nDatenschutzhinweise bestätigt.\nFotos: '+attachments.length,attachments}),signal:AbortSignal.timeout(15000)});if(!r.ok)return fail(502,'E-Mail-Versand momentan nicht möglich. Bitte erneut versuchen.');return res.status(200).json({ok:true});}catch{return fail(502,'E-Mail-Versand momentan nicht möglich. Bitte erneut versuchen.');}
};
